package ui;

public interface Click {
	
	public abstract void onClick();
	
}